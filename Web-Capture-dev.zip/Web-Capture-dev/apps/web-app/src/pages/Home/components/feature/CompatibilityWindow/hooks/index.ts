export * from './useCompatibilityWindow'
