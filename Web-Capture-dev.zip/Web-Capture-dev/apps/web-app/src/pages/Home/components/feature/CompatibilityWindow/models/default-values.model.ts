export const defaultCompatibilityValues = {
  'Webcam Recording': true,
  'Screen Recording': true,
  'Take Screenshot': true
}

export type CompatibilityType = typeof defaultCompatibilityValues


