import { useAuthContext } from '@/services/store/context/user'

export const useGlobalAuth = () => useAuthContext()
