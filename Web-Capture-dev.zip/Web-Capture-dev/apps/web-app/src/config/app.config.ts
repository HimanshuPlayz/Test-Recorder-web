export const appConfig = {
  name: 'WebCapture',
  localStorageKeys: {
    token: 'token',
    user: 'user-data'
  },
  links: {
    github: 'https://github.com/Jes015/Web-Capture'
  }
}
