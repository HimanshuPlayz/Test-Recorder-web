import { UUID } from 'crypto';

export interface JwtPayload {
  id: UUID;
}
